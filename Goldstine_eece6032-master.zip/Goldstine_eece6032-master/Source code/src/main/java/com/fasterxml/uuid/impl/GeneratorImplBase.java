package com.fasterxml.uuid.impl;

/**
 * Shared base class for various UUID generator implementations.
 */
public class GeneratorImplBase
{
}
