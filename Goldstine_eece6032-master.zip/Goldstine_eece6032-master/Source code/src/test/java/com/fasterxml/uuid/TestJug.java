package com.fasterxml.uuid;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.ByteOrder;

import junit.framework.TestCase;

public class TestJug extends TestCase{

//j.main(x);
		
		 public void testMainWithRcommand(){
			 
			 ByteArrayOutputStream out=new ByteArrayOutputStream();
			 System.setOut(new PrintStream(out));
			 
			// System.out.print("hello");
				//Jug j=new Jug();
				
				String[] r={"r"};
				
				
				
				Jug.main(r);
			 assertEquals(38,out.toString().length());
			 
			 
						 //assertEquals(((String)j.main(x)),32);
			 
			 System.setOut(null);
		 }
		 
      public void testMainWithNcommand(){
			 
			 ByteArrayOutputStream out=new ByteArrayOutputStream();
			 System.setOut(new PrintStream(out));
			 
			// System.out.print("hello");
				//Jug j=new Jug();
				
				
				String[] n={"r"};
				
				
				
				Jug.main(n);
				 assertEquals(38,out.toString().length());
			 
						 //assertEquals(((String)j.main(x)),32);
			 
			 System.setOut(null);
		 }
public void testMainWithTcommand(){
	 
	 ByteArrayOutputStream out=new ByteArrayOutputStream();
	 System.setOut(new PrintStream(out));
	 
	// System.out.print("hello");
		//Jug j=new Jug();
		
		
		String[] t={"t"};
		
		
		Jug.main(t);
		 assertEquals(38,out.toString().length());
	 
	 System.setOut(null);
}
		 public static void main(String... args){
			 
			ByteArrayOutputStream b=new ByteArrayOutputStream();
			PrintStream ps=new PrintStream(b);
			ps.print("...");
			
			assertEquals("...", b.toString());
			
			 
		 }
	
	
} 
