#!/bin/sh

java -classpath target/classes $*
